package target_shooting_game;

//Crosshair to track mouse
public class Crosshair {
	
}
