                  .-"```'.
                 /   \    \
                /   / `\__/
                | .'  _  _|
                \(\   6  6 
                 | \   _\ |
                 |\ `~`= `/
                 | '.___.'
             .'` \     |_
                  '-__ / `-

Hello Mr. Paul!
This project was crated by Will Victoria, Suad Mohamud, Jayna John.
Included is a video demoing the game and the project folder.
To run the game just open the project and run the main method in the ShootingGame class.